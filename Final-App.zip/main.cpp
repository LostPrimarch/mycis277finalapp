#include <iostream>
using namespace std;

int Addition(int n1,int n2)
{
// function call for addition in the calculator
int result;
result = n1 + n2;
cout << "number 1" << " + number 2" << " Equals: " << result;
return result;
}

int Subtraction(int n1,int n2)
{
// function call for subtraction in the calculator
int result;
result = n1 - n2;
cout << "number 1" << " + number 2" << " Equals: " << result;
return result;
}

int Multiplication(int n1, int n2)
{
// function call for multiplication in the calculator
int result;
result = n1 * n2;
cout << "number 1" << " + number 2" << " Equals: " << result;
return result;
}

int Division(int n1, int n2)
{
// function call for division in the calculator
int result;
result = n1 / n2;
cout << "number 1" << " + number 2" << " Equals: " << result;
return result;
}

int main() 
{
  float number1, number2;
  char choice;
  cout << "===========Welcome!=============\n";
  cout << "=====Grade School Calculator====\n";
  cout << "========A====S====M====D========\n";
  cout << "Enter 2 numbers\n";
  cout << "Enter number 1: ";
  cin >> number1;
  cout << "Enter number 2: ";
  cin >> number2;
  cout << "Enter Your Choice: ";
  cin >> choice;
  switch(choice) 
  {
      case 'A' :
      Addition(number1,number2);
      break;
      case 'S' :
      Subtraction(number1,number2);
      break;
      case 'M' :
      Multiplication(number1,number2);
      break;
      case 'D' :
      Division(number1,number2);
      break;
      default: 
      cout << "Invalid Choice, Try again.";
  }
return 0;
}